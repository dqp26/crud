<?php
ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class registro_actividad{
	var $idgenero;
	var $nombre;
	var $director
	var$clasificacion
	var $nombre_de_la_pelicula 

function genero (){
}

function insert($moneda) {
		
	if ( ! $this->input->post('nombre'))
		{
		 else {
			$nombre = $this->input->post('nombre');
			$idgenero = $this->input->post('idgenero');
			$director = $this->input->post('director');
			$clasificacion = $this->input->post('clasificacion');
			$nombre_de_la_pelicula = $this->input->post('nombre_de_la_pelicula')			
			if (! $this->input->post('idgenero')) {
				if(!$this->class pelicula.genero ->existe(0, $nombre)) {
					$dat = array('nombre' => $nombre, 'director' => $director, 'nombre_de_la_pelicula' => $nombre_de_la_pelicula, 'clasificacion' => $clasificacion);
					$this->"class.registro"->insertar($dat);
				} else {
									}
			} else {
				$idd = $this->input->post('idgenero');
				$dat = array('nombre' => $nombre);
				$this->"class.registro"->actualizar($dat, $idd);
				
	$sql = "INSERT INTO pelicula.genero( idgenero,nombre,director,clasificacion,nombre_de_la_pelicula ) VALUES ( '$this->idgenero ', '$this->nombre','$this->director','$this->clasificacion,'$this->nombre_de_la_pelicula ')";
	try {
		mysql_query("begin");
		$row = mysql_query($sql);
		mysql_query("commit");

		echo "1";
	}
	catch (DependencyException $e) {
		echo "Error: " . $e;
		mysql_query("rollback");
		echo "-1";
	}
}

function getLista(){

	$sql="SELECT * FROM pelicula.genero";
	try {
		echo "<SELECT idgenero='id_r'>";
		$result = mysql_query($sql);
		while ($row= mysqli_fetch_array($result)){
			echo "<OPTION value='".$row['id´genero']."'> ".$row['nombre ']."'> ".$row['director ']."'> ".$row['clasificacion ']."'> ".$row['nombre_de_la_pelicula ']." </OPTION>";
		}
		echo "</SELECT>";
	}
	catch (DependencyException $e) {
		mysql_query("rollback");
	}
}

function getAutocomplete(){
	$res="";
	$sql="SELECT * FROM pelicula.genero";
	try {
		$result = mysql_query($sql);
		while ($row=  mysql_fetch_array($result)){
			$res .= '"' . $row['idgenero'] . ', ' . $row['nombre'] . $row['director'] .$row['clasificacion'] .$row['nombre de la pelicula'] . '"';
			$res .= ',';
		}
		$res = substr ($res, 0, -2);
		$res = substr ($res, 1);
	}
	catch (DependencyException $e) {
	}
	return $res;
}
}
?>
