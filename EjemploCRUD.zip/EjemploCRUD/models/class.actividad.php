<?php
ini_set('display_errors', 'off');
include_once("resources/class.database.php");

class actividad{
	var $idgenero;
  	var $nombre;
  	var $director;
  	var $clasificacion;
  	var $nombre_de_la_pelicula;

function actividad(){
}

function select($idgenero){
	$sql =  "SELECT * FROM teatro.genero WHERE idgenero = '$idgenero'";
	try {
		$row = mysql_query($sql);
		$row=mysqli_fetch_array($row);
		$this->idgenero = $row['idgenero'];
		$this->nombre = $row['nombre'];
		$this->director= $row['director']; 
		$this->clasificacion= $row ['clasificacion'];
		return true;
	}// QUEDE ACÁ
	
	catch (DependencyException $e) {
	}
}

function delete($idgenero){
	$sql = "DELETE FROM teatro.genero  WHERE idgenero = '$idgenero'";
	try {
		mysql_query("begin");
		$row = mysql_query($sql);
		mysql_query("commit");
		return "1";
	}
	catch (DependencyException $e) {
		mysql_query("rollback");
		return "-1";
	}
}

function insert(){
echo "TEATRO";
	if ($this->validaP($this->idgenero) == false){
		$sql = "INSERT INTO teatro.genero( idgenero ,director , clasificacion , nombre,nombre_de_la_pelicula) VALUES ( '$this->idgenero', '$this->director','$this->clasificacion','$this->nombre''$this->nombre_de_la_pelicula')";
		try {
			mysql_query("begin");
			$row = mysql_query($sql);
			mysql_query("commit");
			echo "1";
		}
		catch (DependencyException $e) {
			echo "Error: " . $e;
			mysql_query("rollback");
			echo "-1";
		}
	}
	else{
		$sql="UPDATE teatro.genero set nombre ='" . $this->nombre . "' WHERE idgenero='" . $this->idgenero . "'";
		mysql_query("begin");
		$row = mysql_query($sql);
		mysql_query("commit");		
		echo "2";
	}
}

function validaP ($idgenero){
      $sql =  "SELECT * FROM teatro.genero WHERE idgenero = '$idgenero'";
      try {
		$row = mysql_query($sql);
		if(mysqli_num_rows($row) == 0){
		        return false;
	        }
		else{
			return true;
		 }
		}
		catch (DependencyException $e) {
			//mysql_query("rollback");
			return false;
		}
}

function getTabla(){
	
	$sql="SELECT * FROM teatro.genero";
	try {
		echo "<div class='container' style='margin-top: 10px'>";
		echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
		echo "<thead>";
		echo "<tr>";
		echo "	<th>Codigo</th>";
		echo "	<th>Descripcion</th>";
		echo "	<th>.</th>";
		echo "</tr>";
		echo "</thead>";
		echo "<tbody>";

		$result = mysql_query($sql);
		while ($row=  mysqli_fetch_array($result)){
			echo "<tr class='gradeA'>";
			echo "	<th>" . $row['idgenero'] . "</th>";
			echo "	<th>" . $row['descripcion'] . "</th>";
			echo "	<th><a href='#' class='btn btn-danger' onclick='elimina(\"" . $row['idgenero'] . "\")'>X<i class='icon-white icon-trash'></i></a>.<a href='#' class='btn btn-primary' onclick='edit(\"" . $row['id'] . "\", \"" . $row['descripcion'] . "\")'>E<i class='icon-white icon-refresh'></i></a></th>";
			echo "</tr>";
		}
		echo "</tbody>";
		echo "</table>";
		echo "</div>";
	}
	catch (DependencyException $e) {
		echo "Procedimiento sql invalido en el servidor";
	}
}

function getTablaInicianPorA(){
	
	$sql="select * from teatro.genero where descripcion like 'A%'";
	try {
		echo "<div class='container' style='margin-top: 10px'>";
		echo "<table cellpadding='0' cellspacing='0' border='0' class='table table-striped table-bordered' id='example'>";
		echo "<thead>";
		echo "<tr>";
		echo "	<th>Codigo</th>";
		echo "	<th>Descripcion</th>";

		echo "</tr>";
		echo "</thead>";
		echo "<tbody>";
		$result = mysql_query($sql);
		while ($row= mysqli_fetch_array($result)){
			echo "<tr class='gradeA'>";
			echo "	<th>" . $row['idgenero'] . "</th>";
			echo "	<th>" . $row['nombre'] . "</th>";
			echo "	<th>" . $row['clasificacion'] . "</th>";
			echo "	<th>" . $row['nombre_de_la_pelicula'] . "</th>";
			echo "	<th>" . $row['director'] . "</th>";
			echo "</tr>";
		}
		echo "</tbody>";
		echo "</table>";
		echo "</div>";
	}
	catch (DependencyException $e) {
		echo "Procedimiento sql invalido en el servidor";
	}
}

function getTablaPDF(){
	
	$sql="select * from teatro.genero";	
	$tabla="";
	try {
		$tabla="<table>";
		$tabla=$tabla . "<tr>";
		$tabla=$tabla . "	<td>Codigo</td>";
		$tabla=$tabla . "	<td>Descripcion</td>";

		$tabla=$tabla . "</tr>";

		$result = mysql_query($sql);
		while ($row= mysqli_fetch_array($result)){
			$tabla=$tabla . "<tr>";
			$tabla=$tabla . "	<td>" . $row['idgenero'] . "</td>";
			$tabla=$tabla . "	<td>" . $row['nombre'] . "</td>";
			$tabla=$tabla . "	<td>" . $row['nombre_de_la_pelicula'] . "</td>";
			$tabla=$tabla . "	<td>" . $row['director'] . "</td>";
			$tabla=$tabla . "	<td>" . $row['clasificacion'] . "</td>";
			$tabla=$tabla . "</tr>";
		}
		$tabla=$tabla . "</table>";
	}
	catch (DependencyException $e) {
		echo "Procedimiento sql invalido en el servidor";
	}
	return $tabla;
}

function getLista(){
	
	$sql="SELECT * FROM teatro.genero";
	try {
		echo "<SELECT id='idgenero'>";
		$result = mysql_query($sql);
		while ($row= mysqli_fetch_array($result)){//$row= pg_fetch_array ,Nota: Esta función define campos NULOS al valor NULL de PHP.
		echo "<OPTION value='".$row['idgenero']."'> ".$row['clasificacion']."'>."$row ['nombre'] ."'>."$row ['nombre_de_la_pelicula'] ".'> ."$row ['director'] ."" </OPTION>";
		}
		echo "</SELECT>";
	}
	catch (DependencyException $e) {
		mysql_query("rollback");
	}
}

function getAutocomplete(){
	$res="";
	$sql="SELECT * FROM teatro.genero";
	try {
		$result = mysql_query($sql);
		while ($row=  mysqli_fetch_array($result)){
			$res .= '"' . $row['idgenero'].',' . $row['clasificacion'].','$row ['nombre'] .','$row ['nombre_de_la_pelicula'] .'> ."$row ['director'] ."" </OPTION>";
		}. '"';
			$res .= ',';
		}
		$res = substr ($res, 0, -2);
		$res = substr ($res, 1);
	}
	catch (DependencyException $e) {
	}
	return $res;
}
}
?>
