<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../models/class.actividad.php");
	$obj = new actividad();
	if (isset($_POST['idgenero']) && isset($_POST['nombre ']) && isset($_POST['clasificacion ']) && isset($_POST['nombre_de_la_pelicula'])&& isset($_POST['director']){
		$obj->id=$_POST['idgenero '];
		$obj->descripcion=$_POST['descripcion'];
		echo $obj->insert();
	}
	else{
		echo "-1";
	}
?>
