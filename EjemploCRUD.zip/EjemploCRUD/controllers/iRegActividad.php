<?php
	ini_set('display_errors', 'on');
	session_start();
	include_once("../models/class.registro.actividad.php");
	$obj = new registro_actividad();
	if (isset($_POST['nombre']) && isset($_POST['nombre_de_la_pelicula ']) && isset($_POST['director '])&& isset($_POST['clasificacion ']{
		$obj->nombre=$_POST['nombre'];
		$obj->idgenero=$_POST['idgenero'];
		$obj->nombre_de_la_pelicula=$_POST['nombre_de_la_pelicula'];
		$obj->director=$_POST['director'];
		$obj->nombre=$_POST['clasificacion'];
		echo $obj->insert();
	}
	else{
		echo "-1";
	}
?>
